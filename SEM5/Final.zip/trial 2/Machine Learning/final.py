import tkinter as tk
from tkinter import ttk
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from tkinter import *
from tkinter import messagebox
from pynput import keyboard
import threading

df = pd.read_csv('Symptom.csv')
df.drop(['Symptom_6', 'Symptom_7', 'Symptom_8', 'Symptom_9', 'Symptom_10', 'Symptom_11', 'Symptom_12', 'Symptom_13',
         'Symptom_14', 'Symptom_15', 'Symptom_16', 'Symptom_17'], axis=1, inplace=True)
cols = df.columns
data = df[cols].values.flatten()
s = pd.Series(data)
s = s.str.strip()
s = s.values.reshape(df.shape)
df = pd.DataFrame(s, columns=df.columns)
df = df.fillna(0)
vals = df.values

df2 = pd.read_csv('Disease Specialist.csv')
specialist = df2['Specialist'].tolist()
edd = df2['Disease'].tolist()

df1 = pd.read_csv('Symptom Severity.csv')
symptoms = df1['Symptom'].unique()
for i in range(len(symptoms)):
    vals[vals == symptoms[i]] = df1[df1['Symptom'] == symptoms[i]]['weight'].values[0]

pd.set_option('future.no_silent_downcasting', True)
d = pd.DataFrame(vals, columns=cols)
d = d.replace('dischromic _patches', 0)
d = d.replace('spotting_ urination', 0)
df = d.replace('foul_smell_of urine', 0)

data = df.iloc[:, 1:].values
labels = df['Disease'].values

rf = RandomForestClassifier(n_estimators=100)
rf = rf.fit(data, labels)

class mainClass(tk.Tk):

    def __init__(self, *args, **kwargs):
        tk.Tk.__init__(self, *args, **kwargs)
        container = tk.Frame(self)
        container.pack(side="top", fill="both", expand=True)
        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0, weight=1)
        self.frames = {}
        for F in (StartPage, PageOne):
            frame = F(container, self)
            self.frames[F] = frame
            frame.grid(row=0, column=0, sticky="nsew")
        self.show_frame(StartPage)

    def show_frame(self, cont):
        frame = self.frames[cont]
        frame.tkraise()

class AutocompleteCombobox(ttk.Combobox):
    def set_completion_list(self, completion_list):
        self._completion_list = sorted(completion_list)
        self._hits = []
        self._hit_index = 0
        self.position = 0
        self.bind('<KeyRelease>', self.handle_keyrelease)
        self['values'] = self._completion_list

    def autocomplete(self, delta=0):
        if delta:
            self.delete(self.position, tk.END)
        else:
            self.position = len(self.get())
        _hits = [item for item in self._completion_list if item.lower().startswith(self.get().lower())]
        if _hits != self._hits:
            self._hit_index = 0
            self._hits = _hits
        if _hits:
            self._hit_index = (self._hit_index + delta) % len(_hits)
            self.delete(0, tk.END)
            self.insert(0, _hits[self._hit_index])
            self.select_range(self.position, tk.END)

    def handle_keyrelease(self, event):
        if event.keysym in ('BackSpace', 'Left', 'Right', 'Up', 'Down'):
            return
        if event.keysym == 'Return':
            self.autocomplete()
        else:
            self.autocomplete()


class StartPage(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        self.controller = controller
        self.rfid_input = ""
        self.rfid_timer = None

        label = tk.Label(self, text="Welcome to the AI-based Medical Specialist Recommendation System", bg='LightSteelBlue1')
        label.config(font=("Bookman Old Style", 28))
        label.pack(pady=20, padx=20)
        self.configure(bg='LightSteelBlue1')

        NameLb = Label(self, text="If you are suffering from a disease and you do not have an idea as to which doctor "
                                  "to go to, so as to get started with the correct treatment, then this recommendation "
                                  "system can help you advise the kind of doctor you must visit, based on the symptoms "
                                  "that your body is showing.", wraplength=1350, bg='LightSteelBlue1')
        NameLb.config(font=("Bookman Old Style", 16))
        NameLb.pack(pady=20, padx=40)

        NameLb2 = Label(self, text="Steps to get an authentic recommendation:                                          "
                                   "                 \n1. Click on the 'Get Recommendation' button. You will be "
                                   "redirected to a new page.\n2.Choose the five most prevalent disease symptoms that "
                                   "your body is showing.      \n\nPro-tip: Assess yourself thoroughly before entering "
                                   "the details in order to get the most apt recommendation from our system.",
                        bg='khaki2')
        NameLb2.config(font=("Bookman Old Style", 16))
        NameLb2.pack(pady=40, padx=40)

        self.listener = keyboard.Listener(on_press=self.on_key_press)
        self.listener.start()

    def on_key_press(self, key):
        try:
            char = key.char
            self.rfid_input += char
            if self.rfid_timer:
                self.rfid_timer.cancel()
            self.rfid_timer = threading.Timer(3.0, self.clear_rfid_input)
            self.rfid_timer.start()
            self.check_rfid_input()
        except AttributeError:
            pass

    def clear_rfid_input(self):
        self.rfid_input = ""

    def check_rfid_input(self):
        if self.rfid_input == "0080423430":
            self.controller.show_frame(PageOne)
            
class PageOne(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        self.configure(bg='RosyBrown2')
        label = tk.Label(self, text="Enter the five most prevalent symptoms that you are facing at the moment", bg='RosyBrown2')
        label.config(font=("Bookman Old Style", 20))
        label.pack(pady=2, padx=2)

        self.symptoms = [StringVar() for _ in range(5)]
        OPTIONS = df1['Symptom'].tolist()

        for i in range(5):
            symptom_label = Label(self, text=f"Symptom {i+1}", bg='RosyBrown2')
            symptom_label.config(font=("Bookman Old Style", 25))
            symptom_label.pack(padx=5, pady=5)

            frame = tk.Frame(self, bg='RosyBrown2')
            frame.pack(padx=5, pady=5)

            symptom_combobox = AutocompleteCombobox(frame, textvariable=self.symptoms[i], font=("Bookman Old Style", 20))
            symptom_combobox.set_completion_list(OPTIONS)
            symptom_combobox.pack(side=tk.LEFT, padx=5, pady=5)

            remove_button = Button(frame, text="X", command=lambda i=i: self.remove_symptom(i))
            remove_button.config(font=("Bookman Old Style", 20), bg='red', fg='white')
            remove_button.pack(side=tk.LEFT, padx=5, pady=5)

        def RF():
            psymptoms = [symptom.get() for symptom in self.symptoms]
            a = np.array(df1["Symptom"])
            b = np.array(df1["weight"])
            for j in range(len(psymptoms)):
                for k in range(len(a)):
                    if psymptoms[j] == a[k]:
                        psymptoms[j] = b[k]
            psy = [psymptoms]
            prob = rf.predict(psy)
            print(prob[0])
            spec = prob[0]
            for l in range(40):
                if spec == edd[l]:
                    t4.delete("1.0", tk.END)
                    t4.insert(tk.END, f"You are recommended to visit any {specialist[l]}")

        def message():
            if any(symptom.get() == "" for symptom in self.symptoms):
                messagebox.showinfo("Warning", "Please enter all 5 symptoms")
                return

            arr = [symptom.get() for symptom in self.symptoms]
            if len(arr) != len(set(arr)):
                messagebox.showinfo("Warning", "Same symptoms cannot be repeated")
                return

            RF()

        lr = Button(self, text="Predict", height=1, width=12, command=message)
        lr.config(font=("Bookman Old Style", 22))
        lr.pack(padx=5, pady=5)

        t4 = Text(self, height=2, width=40)
        t4.config(font=("Bookman Old Style", 20))
        t4.pack(padx=5, pady=5)

    def remove_symptom(self, index):
        self.symptoms[index].set("")

app = mainClass()
app.mainloop()
