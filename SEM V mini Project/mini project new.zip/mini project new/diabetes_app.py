import streamlit as st
import numpy as np
import joblib
import matplotlib.pyplot as plt
from datetime import datetime
import pymongo
from pymongo import MongoClient


client = MongoClient("mongodb+srv://diabetesdb:Qwert123@cluster0.cgfu1.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")

# Connect to your database
db = client['diabetes_app']  

# Select the users collection
users_collection = db['users']  


st.set_page_config(layout="wide")  

# Load and save user data functions
def load_user_data(username):
    user = users_collection.find_one({"username": username})
    return user if user else None

# User registration and login functions
def register_user(username, password, phone, email, gender):
    if load_user_data(username):  # Check if the user already exists
        return "Username already exists!"
    
    new_user = {
        "username": username,
        "password": password,
        "phone": phone,
        "email": email,
        "gender": gender,
        "predictions": []
    }
    users_collection.insert_one(new_user)
    return "User registered successfully!"

def login_user(username, password):
    user = load_user_data(username)
    if user and user['password'] == password:
        return True
    return False

# Save and retrieve predictions
def save_prediction(username, prediction, details, remedies):
        # Create the prediction entry
    prediction_entry = {
        "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "prediction": prediction,
        "details": details,
        "remedies": remedies
    }
    
    # Update the user's predictions
    users_collection.update_one(
        {"username": username},  # Filter
        {"$push": {"predictions": prediction_entry}}  # Push new prediction
    )

def get_last_prediction(username):
    user = users_collection.find_one({"username": username}, {"predictions": 1})
    if user and 'predictions' in user and len(user['predictions']) > 0:
        return user['predictions'][-1]
    return None

# Load the saved model and scaler with caching
@st.cache_resource
def load_model():
    classifier = joblib.load('diabetes_svm_model.joblib')
    scaler = joblib.load('diabetes_scaler.joblib')
    return classifier, scaler


classifier, scaler = load_model()

# Load the images
def load_images():
    return {
        "login_image": r"C:\\Users\\91885\\Desktop\\sem 5 mini\\abc.jpg",
    }

images = load_images()


# Initialize session state variables
if 'logged_in' not in st.session_state:
    st.session_state['logged_in'] = False
if 'username' not in st.session_state:
    st.session_state['username'] = ''
if 'view_profile' not in st.session_state:
    st.session_state['view_profile'] = False

# Function for Home Page
# Function for Home Page
def home_page():
    st.markdown(f"<h1 style='color: #2E86C1;'>Welcome to the Diabetes Prediction App</h1>", unsafe_allow_html=True)
    st.image(images['login_image'], width=300)  # You can adjust the width value as needed
    
    st.write("This app allows you to predict the likelihood of having diabetes based on several health metrics.")
    
    # Additional Information
    st.markdown(f"<h2 style='color: #D35400;'>What is Diabetes?</h2>", unsafe_allow_html=True)
    st.write(""" 
        Diabetes is a chronic health condition that affects how your body turns food into energy. 
        There are two main types:
        - Type 1 Diabetes: The body does not produce insulin.
        - Type 2 Diabetes: The body does not use insulin properly.
    """)
    
    st.markdown(f"<h2 style='color: #D35400;'>How to Use This App:</h2>", unsafe_allow_html=True)
    st.write(""" 
        - **Register**: Create an account to track your predictions and remedies. 
        - **Login**: Access your profile to view past predictions and health tips. 
        - **Predict**: Enter your health metrics to see if you may be at risk for diabetes. 
        - **Profile**: Review your prediction history and remedies. 
    """)
    
    st.markdown(f"<h2 style='color: #D35400;'>Why Regular Monitoring is Important?</h2>", unsafe_allow_html=True)
    st.write(""" 
        Regular monitoring of your health metrics can help you manage diabetes effectively. 
        Early detection and lifestyle adjustments can significantly improve your health outcomes.
    """)
    
    st.markdown(f"<h2 style='color: #D35400;'>Health Tips:</h2>", unsafe_allow_html=True)
    st.write(""" 
        - Maintain a balanced diet rich in vegetables, fruits, and whole grains. 
        - Engage in regular physical activity (aim for at least 150 minutes per week). 
        - Stay hydrated and avoid sugary drinks. 
        - Regularly check your blood sugar levels and consult with healthcare providers.
    """)
    

# Function for Profile Page
def profile_page():
    st.title(f"Profile of {st.session_state['username']}")
    last_prediction = get_last_prediction(st.session_state['username'])
    
    if last_prediction:
        st.subheader("Last Prediction")
        st.write(f"Prediction Date: {last_prediction['date']}")
        st.write(f"Prediction: {last_prediction['prediction']}")
        st.write(f"Details: {last_prediction['details']}")
        
        # Display remedies as bullet points
        st.subheader("Remedies:")
        for remedy in last_prediction['remedies']:
            st.write(f"- {remedy}")  # Show each remedy as a point
    else:
        st.info("No predictions found.")
    
    # Load all previous predictions for the user
    user = users_collection.find_one({"username": st.session_state['username']}, {"predictions": 1})
    if user and 'predictions' in user:
        predictions = user['predictions']
        
        # Prepare data for plotting
        dates = [datetime.strptime(prediction['date'], "%Y-%m-%d %H:%M:%S") for prediction in predictions]
        results = [1 if prediction['prediction'] == "Diabetes Positive" else 0 for prediction in predictions]

        # Create a line plot
        plt.figure(figsize=(12, 6))
        plt.plot(dates, results, marker='o', linestyle='-', color='blue', markersize=8, linewidth=2)

        # Adding labels and title
        plt.title("Diabetes Predictions Over Time", fontsize=16)
        plt.xlabel("Date", fontsize=14)
        plt.ylabel("Prediction Result", fontsize=14)
        plt.yticks([0, 1], ['Diabetes Negative', 'Diabetes Positive'], fontsize=12)
        plt.xticks(rotation=45, fontsize=12)

        # Adding grid lines for better readability
        plt.grid(visible=True, linestyle='--', alpha=0.7)
        
        # Highlighting predictions
        for i, result in enumerate(results):
            if result == 1:
                plt.text(dates[i], result, 'Positive', color='red', fontsize=10, ha='center', va='bottom')
            else:
                plt.text(dates[i], result, 'Negative', color='green', fontsize=10, ha='center', va='bottom')

        plt.tight_layout()  # Adjust layout to fit labels
        st.pyplot(plt)  # Display the plot



# Function for Prediction Page with diverse input types
def prediction_page():
    st.markdown(f"<h1 style='color: #2E86C1;'>Diabetes Prediction</h1>", unsafe_allow_html=True)
    st.write("Predict whether you are likely to have diabetes based on your health metrics.")
    
    # Age input with information
    st.markdown('<span style="font-size: 20px; font-weight: bold;">Age:</span>', unsafe_allow_html=True)
    age = st.number_input("", min_value=15, max_value=80, value=30, help="Age in years (between 15 and 80).")
    
    # Hypertension input (Yes/No)
    st.markdown('<span style="font-size: 20px; font-weight: bold;">Hypertension:</span>', unsafe_allow_html=True)
    hypertension = st.selectbox("", ["Yes", "No"], help="Do you have a history of hypertension (high blood pressure)?")
    hypertension = 1 if hypertension == "Yes" else 0

    # Heart Disease input (Yes/No)
    st.markdown('<span style="font-size: 20px; font-weight: bold;">Heart Disease:</span>', unsafe_allow_html=True)
    heart_disease = st.selectbox("", ["Yes", "No"], help="Have you been diagnosed with heart disease?")
    heart_disease = 1 if heart_disease == "Yes" else 0

    # BMI input with information
    st.markdown('<span style="font-size: 20px; font-weight: bold;">BMI:</span>', unsafe_allow_html=True)
    bmi = st.number_input("", min_value=0.0, max_value=70.0, value=25.0, help="Body mass index (weight in kg/(height in m)^2).")
    
    # HbA1c Level input with information
    st.markdown('<span style="font-size: 20px; font-weight: bold;">HbA1c Level:</span>', unsafe_allow_html=True)
    hba1c_level = st.number_input("", min_value=0.0, max_value=15.0, value=5.5, help="HbA1c level (a measure of your average blood sugar levels over the past 2-3 months).")
    
    # Blood Glucose Level input with information
    st.markdown('<span style="font-size: 20px; font-weight: bold;">Blood Glucose Level:</span>', unsafe_allow_html=True)
    blood_glucose_level = st.number_input("", min_value=0, max_value=200, value=100, help="Current blood glucose level (mg/dL).")

    # Perform the prediction when the button is clicked
    if st.button("Predict"):
        try:
            # Collecting inputs in an array
            input_data = np.array([[age, hypertension, heart_disease, bmi, hba1c_level, blood_glucose_level]])

            # Scale the input data
            scaled_data = scaler.transform(input_data)
            
            # Predict using the model
            prediction = classifier.predict(scaled_data)

            # Displaying prediction result with color coding
            prediction_text = "Diabetes Positive" if prediction == 1 else "Diabetes Negative"
            if prediction_text == "Diabetes Positive":
                st.markdown(f"<h2 style='color:red;'>{prediction_text}</h2>", unsafe_allow_html=True)  # Red for high risk
                
                # Base remedies for diabetes positive cases
                remedies = [
                    "Maintain a healthy diet with low sugar and carbs.",
                    "Exercise regularly for at least 30 minutes a day.",
                    "Monitor your blood sugar levels daily.",
                    "Consult with a healthcare provider regularly."
                ]
                
                # Check specific inputs and add corresponding remedies
                if blood_glucose_level > 140:
                    remedies.append("Consider reducing sugar intake and regularly check your blood glucose levels.")
                if hba1c_level > 6.5:
                    remedies.append("Consult your doctor about adjusting medications or diet to lower HbA1c levels.")
                if bmi > 30:
                    remedies.append("Focus on weight loss through a balanced diet and regular physical activity.")
                if hypertension == 1:
                    remedies.append("Monitor your blood pressure and reduce salt intake.")
                if heart_disease == 1:
                    remedies.append("Ensure regular heart check-ups and take prescribed medications.")
                
                # Display the remedies
                st.subheader("Suggested Remedies:")
                for remedy in remedies:
                    st.write(f"- {remedy}")
                
                # Suggest doctors
                doctors = [
                    {"name": "Dr. Manish Sachdev", "specialty": "Diabetologist", "contact": "+91 78548564985"},
                    {"name": "Dr. Rahul Jalgaonka", "specialty": "Diabetologist", "contact": "+91 9876543521"}
                ]
                
                # Display the doctors
                st.subheader("Recommended Doctors:")
                for doctor in doctors:
                    st.write(f"- **{doctor['name']}** - {doctor['specialty']}, Contact: {doctor['contact']}")
                    
            else:
                st.markdown(f"<h2 style='color:green;'>{prediction_text}</h2>", unsafe_allow_html=True)  # Green for low risk

            # Save the prediction with remedies if positive
            details = {
                "Age": age,
                "Hypertension": hypertension,
                "Heart Disease": heart_disease,
                "BMI": bmi,
                "HbA1c Level": hba1c_level,
                "Blood Glucose Level": blood_glucose_level
            }
            
            if prediction_text == "Diabetes Positive":
                save_prediction(st.session_state['username'], prediction_text, details, remedies)
            else:
                save_prediction(st.session_state['username'], prediction_text, details, [])

        except Exception as e:
            st.error(f"An error occurred: {e}")


            
# Function to handle user registration
def register_page():
    st.subheader("Register")
    with st.form("register_form", clear_on_submit=True):
        reg_username = st.text_input("Username")
        reg_password = st.text_input("Password", type="password")
        reg_phone = st.text_input("Phone Number")
        reg_email = st.text_input("Email")
        reg_gender = st.selectbox("Gender", options=["Select Gender", "Male", "Female", "Other"])
        register_button = st.form_submit_button("Register")
        
        if register_button:
            if reg_gender == "Select Gender":
                st.error("Please select a gender.")
            else:
                result = register_user(reg_username, reg_password, reg_phone, reg_email, reg_gender)
                if result == "User registered successfully!":
                    st.success(result)
                else:
                    st.error(result)


# Function to handle user login
def login_page():
    st.subheader("Login")
    with st.form("login_form", clear_on_submit=True):
        login_username = st.text_input("Username")
        login_password = st.text_input("Password", type="password")
        login_button = st.form_submit_button("Login")
        if login_button:
            if login_user(login_username, login_password):
                st.session_state['logged_in'] = True
                st.session_state['username'] = login_username
                st.success(f"Welcome {login_username}!")
                page="home"
            else:
                st.error("Invalid credentials.")
    if st.button("New User?"):
        register_page()

# Logout button
def logout():
    st.session_state['logged_in'] = False
    st.session_state['username'] = ''
    st.success("You have logged out.")


# Sidebar-based navigation and Page Rendering
if st.session_state['logged_in']:
    st.sidebar.button("Logout", on_click=logout)

page = st.sidebar.radio("Navigate", ["Home", "Prediction", "Profile", "Login"])

if page == "Home":
    home_page()
elif page == "Profile":
    if st.session_state['logged_in']:
        profile_page()
    else:
        st.warning("Please log in to view your profile.")
elif page == "Prediction":
    if st.session_state['logged_in']:
        prediction_page()
    else:
        st.warning("Please log in to make a prediction.")
elif page == "Login":
    login_page()