# Import necessary libraries
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn import svm
from sklearn.metrics import accuracy_score
from imblearn.over_sampling import SMOTE
import joblib

# Load the dataset
diabetes_dataset = pd.read_csv('/content/diabetes_prediction_dataset.csv')

# Data preprocessing
X = diabetes_dataset.drop(columns=['diabetes', 'smoking_history', 'gender'], axis=1)
Y = diabetes_dataset['diabetes']

# Handle class imbalance using SMOTE
smote = SMOTE(sampling_strategy="auto")
X_sm, Y_sm = smote.fit_resample(X, Y)

# Standardize the data
scaler = StandardScaler()
scaler.fit(X_sm)
X_standardized = scaler.transform(X_sm)

# Train-test split
X_train, X_test, Y_train, Y_test = train_test_split(X_standardized, Y_sm, test_size=0.2, stratify=Y_sm, random_state=42)

# Train the model using SVM
classifier = svm.SVC(kernel='rbf')
classifier.fit(X_train, Y_train)

# Accuracy on training data
X_train_prediction = classifier.predict(X_train)
training_data_accuracy = accuracy_score(X_train_prediction, Y_train)
print(f'Accuracy score of training data: {training_data_accuracy}')

# Accuracy on test data
X_test_prediction = classifier.predict(X_test)
test_data_accuracy = accuracy_score(X_test_prediction, Y_test)
print(f'Accuracy score of test data: {test_data_accuracy}')

# Save the model
joblib.dump(classifier, 'diabetes_svm_model.pkl')
print('Model saved as diabetes_svm_model.pkl')

# Save the scaler for future use
joblib.dump(scaler, 'scaler.pkl')
print('Scaler saved as scaler.pkl')

# Making a predictive system
def get_user_input():
    input_string = input("Enter values for age, hypertension, heart_disease, bmi, HbA1c_level, blood_glucose_level (comma-separated): ")
    inputs = list(map(float, input_string.split(',')))
    return inputs

# Get user input
input_data = get_user_input()

# Convert user input to numpy array and reshape
input_data_as_array = np.asarray(input_data).reshape(1, -1)

# Standardize the user input
std_input_data = scaler.transform(input_data_as_array)

# Make prediction
prediction = classifier.predict(std_input_data)

# Output the prediction result
if prediction[0] == 0:
    print('Patient is non-diabetic')
else:
    print('Patient is diabetic')
