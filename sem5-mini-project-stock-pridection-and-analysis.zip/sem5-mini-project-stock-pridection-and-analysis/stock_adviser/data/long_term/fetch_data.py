import os
import sqlite3
import yfinance as yf
from datetime import datetime
import time
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
import pandas as pd
import numpy as np

# Define the path to the SQLite database
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATABASE_PATH = os.path.join(BASE_DIR, 'nifty50_data.db')
MODEL_DIR = r"C:\Users\Shubham\OneDrive\Desktop\project mini\stock_adviser\data\long_term\long_models"
JSON_DIR = r"C:\Users\Shubham\OneDrive\Desktop\project mini\stock_adviser\data\long_term"
 
# Ensure the directories exist
os.makedirs(MODEL_DIR, exist_ok=True)
os.makedirs(JSON_DIR, exist_ok=True)


# Connect to the database
def connect_to_db():
    conn = sqlite3.connect(DATABASE_PATH)
    return conn

# Clean the ticker for table names
def clean_table_name(ticker):
    return ticker.replace(".", "_").replace("-", "_")

# Function to calculate Bollinger Bands
def calculate_bollinger_bands(df, window=20):
    df['MA20'] = df['Close'].rolling(window=window).mean()
    df['Upper_Band'] = df['MA20'] + 2 * df['Close'].rolling(window=window).std()
    df['Lower_Band'] = df['MA20'] - 2 * df['Close'].rolling(window=window).std()

# Function to compute the Relative Strength Index (RSI)
def compute_rsi(series, window=14):
    delta = series.diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=window).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=window).mean()
    rs = gain / loss
    return 100 - (100 / (1 + rs))

# Function to compute the Moving Average Convergence Divergence (MACD)
def compute_macd(series):
    exp1 = series.ewm(span=12, adjust=False).mean()
    exp2 = series.ewm(span=26, adjust=False).mean()
    return exp1 - exp2

# Fetch historical data and save to the database without duplication
def fetch_and_store_data(tickers, retries=3):
    conn = connect_to_db()
    cursor = conn.cursor()
    today = datetime.today().strftime('%Y-%m-%d')

    for ticker in tickers:
        table_name = clean_table_name(ticker)
        table_name_safe = f'"{table_name}"'
        
        cursor.execute(f'''
            CREATE TABLE IF NOT EXISTS {table_name_safe} (
                Date TEXT PRIMARY KEY,
                Open REAL,
                High REAL,
                Low REAL,
                Close REAL,
                Volume INTEGER,
                MA20 REAL,
                Upper_Band REAL,
                Lower_Band REAL,
                RSI REAL,
                MACD REAL
            )
        ''')

        attempt = 0
        while attempt < retries:
            try:
                stock_data = yf.download(ticker, start="2010-01-01", end=today)

                # Calculate indicators
                stock_data['MA20'] = stock_data['Close'].rolling(window=20).mean()
                calculate_bollinger_bands(stock_data)
                stock_data['RSI'] = compute_rsi(stock_data['Close'])
                stock_data['MACD'] = compute_macd(stock_data['Close'])

                for date, row in stock_data.iterrows():
                    cursor.execute(f'''
                        INSERT OR IGNORE INTO {table_name_safe} (Date, Open, High, Low, Close, Volume, MA20, Upper_Band, Lower_Band, RSI, MACD)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ''', (date.strftime('%Y-%m-%d'), row['Open'], row['High'], row['Low'], row['Close'], row['Volume'], row['MA20'], row['Upper_Band'], row['Lower_Band'], row['RSI'], row['MACD']))

                conn.commit()
                print(f"Data fetched and stored for {ticker}")
                break
            except Exception as e:
                attempt += 1
                wait_time = 2 ** attempt
                print(f"Failed to fetch data for {ticker} (Attempt {attempt}/{retries}): {e}")
                if attempt < retries:
                    print(f"Retrying in {wait_time} seconds...")
                    time.sleep(wait_time)
                else:
                    print(f"Max retries reached for {ticker}. Moving on to the next ticker.")

    conn.close()
    
import os
import joblib
import json
def long_term_prediction(tickers):
    for ticker in tickers:
        conn = connect_to_db()
        table_name = clean_table_name(ticker)
        cursor = conn.cursor()
        
        cursor.execute(f'SELECT * FROM "{table_name}" ORDER BY Date')
        data = cursor.fetchall()
        
        # Create a DataFrame
        stock_data = pd.DataFrame(data, columns=['Date', 'Open', 'High', 'Low', 'Close', 'Volume', 'MA20', 'Upper_Band', 'Lower_Band', 'RSI', 'MACD'])
        stock_data['Date'] = pd.to_datetime(stock_data['Date'])
        stock_data.set_index('Date', inplace=True)

        # Drop rows with NaN values (if any)
        stock_data.dropna(inplace=True)

        # Split the data into features (X) and target (y)
        X = stock_data[['Open', 'High', 'Low', 'Volume', 'MA20', 'Upper_Band', 'Lower_Band', 'RSI', 'MACD']]
        y = stock_data['Close']

        # Split into training and testing sets
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

        model_file = os.path.join(MODEL_DIR, f'{ticker}_model.joblib')
        
        # Check if the model already exists
        if os.path.exists(model_file):
            model = joblib.load(model_file)  # Load the existing model
            print(f'Loaded existing model for {ticker}')
        else:
            # Train the linear regression model
            model = LinearRegression()
            model.fit(X_train, y_train)

            # Save the trained model
            joblib.dump(model, model_file)
            print(f'Trained and saved model for {ticker}')

        # Make predictions
        y_pred = model.predict(X_test)

        # Evaluate the model
        mse = mean_squared_error(y_test, y_pred)
        r2 = r2_score(y_test, y_pred)
        mape = np.mean(np.abs((y_test - y_pred) / y_test)) * 100
        print(f'Mean Absolute Percentage Error (MAPE) for {ticker}: {mape:.2f}%')

        # Calculate the percentage of acceptable predictions based on a threshold
        threshold = 0.005  # 0.5% threshold
        acceptable_predictions = np.sum(np.abs((y_test - y_pred) / y_test) < threshold)
        accuracy_percentage = (acceptable_predictions / len(y_test)) * 100
        print(f'Accuracy of predictions within {threshold*100}% for {ticker}: {accuracy_percentage:.2f}%')

        # Calculate the number of predictions lower than actual values
        lower_predictions_count = np.sum(y_pred < y_test)
        total_predictions = len(y_test)
        
        # Calculate the percentage of lower predictions
        lower_prediction_percentage = (lower_predictions_count / total_predictions) * 100
        print(f'Percentage of predictions lower than actual values for {ticker}: {lower_prediction_percentage:.2f}%')

        print(f'Model Evaluation for {ticker}:')
        print(f'Mean Squared Error: {mse}')
        print(f'R^2 Score: {r2}')

        # Calculate price predictions for specific timeframes
        last_price = stock_data['Close'].iloc[-1]
        predictions = {
            "15_days": last_price * (1 + 0.05),  # Assuming 5% growth in 15 days
            "1_month": last_price * (1 + 0.1),   # Assuming 10% growth in 1 month
            "6_months": last_price * (1 + 0.2),  # Assuming 20% growth in 6 months
            "1_year": last_price * (1 + 0.3)     # Assuming 30% growth in 1 year
        }

        print(f'Predictions for {ticker}:')
        print(f'Price after 15 days: {predictions["15_days"]:.2f}')
        print(f'Price after 1 month: {predictions["1_month"]:.2f}')
        print(f'Price after 6 months: {predictions["6_months"]:.2f}')
        print(f'Price after 1 year: {predictions["1_year"]:.2f}')

        # Save predictions to JSON file
        save_to_json({ticker: predictions})

        conn.close()

    
    
# Calculate price range for purchase with more realistic limits
def calculate_price_range(stock_data):
    last_close_price = stock_data['Close'].iloc[-1]
    lower_bound = last_close_price * 0.95  # 5% below the last close price
    upper_bound = last_close_price * 1.05  # 5% above the last close price
    return lower_bound, upper_bound

# Goal time to grow based on defined annual growth rate
def estimate_goal_time_annual(stock_data, target_price, annual_growth_rate):
    current_price = stock_data['Close'].iloc[-1]
    
    if current_price <= 0:
        return np.inf  # Avoid division by zero
    
    # Calculate the number of years to reach target price
    years_to_target = (target_price - current_price) / (current_price * annual_growth_rate)
    return max(years_to_target * 365, 0)  # Convert years to days

def save_to_json(predictions):
    json_file_path = os.path.join(JSON_DIR, 'predictions.json')
    
    if os.path.exists(json_file_path):
        with open(json_file_path, 'r') as json_file:
            data = json.load(json_file)
    else:
        data = {}

    data.update(predictions)

    with open(json_file_path, 'w') as json_file:
        json.dump(data, json_file, indent=4)

    print(f'Saved predictions to {json_file_path}')
        
# Define risk levels based on historical volatility
def calculate_risk_level(stock_data):
    volatility = stock_data['Close'].pct_change().std() * np.sqrt(252)  # Annualized volatility
    if volatility < 0.2:
        return 'Low'
    elif volatility < 0.5:
        return 'Medium'
    else:
        return 'High'

if __name__ == "__main__":
    nifty_50_tickers = [
        "RELIANCE.NS", "HDFCBANK.NS", "ICICIBANK.NS", "INFY.NS",
        "TCS.NS", "LT.NS", "KOTAKBANK.NS", "SBIN.NS", "BHARTIARTL.NS",
        "ITC.NS", "HINDUNILVR.NS", "ASIANPAINT.NS", "AXISBANK.NS", "BAJFINANCE.NS",
        "HCLTECH.NS", "MARUTI.NS", "ULTRACEMCO.NS", "TITAN.NS", "SUNPHARMA.NS",
        "ADANIENT.NS", "NTPC.NS", "ONGC.NS", "POWERGRID.NS", "WIPRO.NS",
        "INDUSINDBK.NS", "M&M.NS", "NESTLEIND.NS", "JSWSTEEL.NS", "TECHM.NS",
        "TATAMOTORS.NS", "DIVISLAB.NS", "BPCL.NS", "HEROMOTOCO.NS", "DRREDDY.NS",
        "GRASIM.NS", "CIPLA.NS", "APOLLOHOSP.NS", "TATACONSUM.NS",
        "TATASTEEL.NS", "BRITANNIA.NS", "EICHERMOT.NS", "ADANIPORTS.NS", "BAJAJFINSV.NS",
        "COALINDIA.NS", "HDFCLIFE.NS", "SBILIFE.NS", "UPL.NS", "DEEPAKNTR.NS"
    ]
        
    # Fetch data for Nifty 50 tickers
    fetch_and_store_data(nifty_50_tickers)
    
    # Perform long-term prediction for a specific ticker
    long_term_prediction(nifty_50_tickers)
