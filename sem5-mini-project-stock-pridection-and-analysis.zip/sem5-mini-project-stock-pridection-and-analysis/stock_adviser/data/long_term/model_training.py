import sqlite3
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
import yfinance as yf
"""
# Step 1: Connect to database and fetch data
def fetch_stock_data(ticker):
    conn = sqlite3.connect('nifty50_data.db')
    query = f"SELECT * FROM {ticker.replace('.', '_')}"
    stock_df = pd.read_sql(query, conn)
    stock_df['Date'] = pd.to_datetime(stock_df['Date'])
    conn.close()
    return stock_df

# Step 2: Prepare the data for modeling
def prepare_data(df):
    df = df[['Date', 'Open', 'High', 'Low', 'Close', 'Volume']].dropna()
    df['Date'] = pd.to_numeric(df['Date'])  # Convert date to numerical format
    X = df[['Date', 'Open', 'High', 'Low', 'Volume']]
    y = df['Close']
    return train_test_split(X, y, test_size=0.2, random_state=42)  # 80% training, 20% testing

# Step 3: Train linear regression model
def train_model(X_train, y_train):
    model = LinearRegression()
    model.fit(X_train, y_train)
    return model

# Step 4: Predict future prices
def predict_future_prices(model, X_test):
    return model.predict(X_test)

# Step 5: Determine how long to hold
def calculate_hold_duration(predicted_prices, purchase_price):
    target_price = purchase_price * 1.10  # 10% profit threshold
    for i, predicted_price in enumerate(predicted_prices):
        if predicted_price >= target_price:
            return i + 1  # Return the number of days to hold
    return len(predicted_prices)  # If no target reached, hold for the full period

# Step 6: Calculate accuracy percentage
def calculate_accuracy(y_true, y_pred, tolerance=0.05):
    errors = np.abs(y_true - y_pred) / y_true
    accuracy = np.mean(errors < tolerance) * 100  # Accuracy in percentage
    return accuracy

# Example usage
if __name__ == "__main__":
    ticker = "SBIN.NS"  # Example ticker
    stock_data = fetch_stock_data(ticker)

    X_train, X_test, y_train, y_test = prepare_data(stock_data)
    model = train_model(X_train, y_train)

    # Get predictions on training set for accuracy calculation
    train_predictions = model.predict(X_train)

    # Evaluate model performance
    predictions = predict_future_prices(model, X_test)
    purchase_price = stock_data['Close'].iloc[-1]  # Last closing price
    hold_duration = calculate_hold_duration(predictions, purchase_price)

    mse = mean_squared_error(y_test, predictions)
    r2 = r2_score(y_test, predictions)  # R² score for accuracy

    # Calculate and print accuracy percentage
    accuracy_percentage = calculate_accuracy(y_train, train_predictions)
    
    print(f"Mean Squared Error (MSE): {mse}")
    print(f"R² Score: {r2}")  # R² value close to 1 indicates a good fit
    print(f"Recommended hold duration: {hold_duration} days")
    print(f"Training Accuracy Percentage: {accuracy_percentage:.2f}%")  # Print accuracy percentage
"""

"""
import sqlite3
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
import yfinance as yf

# Step 1: Connect to database and fetch data
def fetch_stock_data(ticker):
    conn = sqlite3.connect('nifty50_data.db')
    query = f"SELECT * FROM {ticker.replace('.', '_')}"
    stock_df = pd.read_sql(query, conn)
    stock_df['Date'] = pd.to_datetime(stock_df['Date'])
    conn.close()
    return stock_df

# Step 2: Prepare the data for modeling
def prepare_data(df):
    df = df[['Date', 'Open', 'High', 'Low', 'Close', 'Volume']].dropna()
    df['Date'] = pd.to_numeric(df['Date'])  # Convert date to numerical format
    X = df[['Date', 'Open', 'High', 'Low', 'Volume']]
    y = df['Close']
    return train_test_split(X, y, test_size=0.2, random_state=42)  # 80% training, 20% testing

# Step 3: Train linear regression model
def train_model(X_train, y_train):
    model = LinearRegression()
    model.fit(X_train, y_train)
    return model

# Step 4: Predict future prices
def predict_future_prices(model, X_test):
    return model.predict(X_test)

# Step 5: Determine how long to hold
def calculate_hold_duration(predicted_prices, purchase_price):
    target_price = purchase_price * 1.10  # 10% profit threshold
    for i, predicted_price in enumerate(predicted_prices):
        if predicted_price >= target_price:
            return i + 1  # Return the number of days to hold
    return len(predicted_prices)  # If no target reached, hold for the full period

# Step 6: Calculate accuracy percentage
def calculate_accuracy(y_true, y_pred, tolerance=0.03):
    errors = np.abs(y_true - y_pred) / y_true
    accuracy = np.mean(errors < tolerance) * 100  # Accuracy in percentage
    return accuracy

# Step 7: Predict future prices for specified days
def predict_future_days(model, last_data, num_days):
    future_prices = []
    current_data = last_data.copy()
    
    for _ in range(num_days):
        # Predict the next price
        predicted_price = model.predict([current_data])[0]
        future_prices.append(predicted_price)
        
        # Update current_data with the predicted price
        # Shift the values (assuming last predicted price can influence next)
        current_data = [current_data[0] + 1, predicted_price, predicted_price, predicted_price, current_data[4]]  # Simulated values for next prediction

    return future_prices

# Example usage
if __name__ == "__main__":
    ticker = "SBIN.NS"  # Example ticker
    stock_data = fetch_stock_data(ticker)

    X_train, X_test, y_train, y_test = prepare_data(stock_data)
    model = train_model(X_train, y_train)

    # Get predictions on training set for accuracy calculation
    train_predictions = model.predict(X_train)

    # Evaluate model performance
    predictions = predict_future_prices(model, X_test)
    purchase_price = stock_data['Close'].iloc[-1]  # Last closing price
    hold_duration = calculate_hold_duration(predictions, purchase_price)

    # Calculate and print accuracy percentage
    accuracy_percentage = calculate_accuracy(y_train, train_predictions)

    # Predict future prices for the next 15 days
    last_data = X_train.iloc[-1].values  # Get the last row of the training data for predictions
    future_prices = predict_future_days(model, last_data, num_days=15)

    mse = mean_squared_error(y_test, predictions)
    r2 = r2_score(y_test, predictions)  # R² score for accuracy

    print(f"Mean Squared Error (MSE): {mse}")
    print(f"R² Score: {r2}")  # R² value close to 1 indicates a good fit
    print(f"Recommended hold duration: {hold_duration} days")
    print(f"Training Accuracy Percentage: {accuracy_percentage:.2f}%")  # Print accuracy percentage
    print(f"Predicted Prices for the next 15 days: {future_prices}")
"""
'''
import sys
import sqlite3
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.tree import DecisionTreeRegressor
from sklearn.svm import SVR
from sklearn.metrics import mean_squared_error, r2_score
from PyQt5.QtWidgets import (QApplication, QWidget, QVBoxLayout, QLabel, 
                             QPushButton, QComboBox, QTextEdit, QLineEdit)

class StockPredictorApp(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.setWindowTitle("Stock Predictor")
        layout = QVBoxLayout()

        self.stock_label = QLabel("Select Stock:")
        self.stock_combo = QComboBox()
        self.stock_combo.addItems(["RELIANCE_NS", "HDFCBANK_NS", "ICICIBANK_NS"])  # Add more tickers

        self.model_label = QLabel("Select Model:")
        self.model_combo = QComboBox()
        self.model_combo.addItems(["Linear Regression", "Random Forest", "Decision Tree", "SVR", "Gradient Boosting"])

        self.param_label = QLabel("Enter Hyperparameters (comma separated):")
        self.param_input = QLineEdit()  # For hyperparameter input

        self.result_area = QTextEdit()
        self.result_area.setReadOnly(True)

        self.train_button = QPushButton("Train Model")
        self.train_button.clicked.connect(self.train_model)

        layout.addWidget(self.stock_label)
        layout.addWidget(self.stock_combo)
        layout.addWidget(self.model_label)
        layout.addWidget(self.model_combo)
        layout.addWidget(self.param_label)
        layout.addWidget(self.param_input)
        layout.addWidget(self.train_button)
        layout.addWidget(self.result_area)

        self.setLayout(layout)

    def fetch_stock_data(self, ticker):
        conn = sqlite3.connect('nifty50_data.db')
        query = f"SELECT * FROM {ticker.replace('.', '_')}"
        stock_df = pd.read_sql(query, conn)
        stock_df['Date'] = pd.to_datetime(stock_df['Date'])
        conn.close()
        return stock_df

    def prepare_data(self, df):
        df = df[['Date', 'Open', 'High', 'Low', 'Close', 'Volume']].dropna()
        df['Date'] = pd.to_numeric(df['Date'])
        X = df[['Date', 'Open', 'High', 'Low', 'Volume']]
        y = df['Close']
        return train_test_split(X, y, test_size=0.2, random_state=42)

    def train_model(self):
        ticker = self.stock_combo.currentText()
        model_choice = self.model_combo.currentText()
        hyperparams = self.param_input.text()

        stock_data = self.fetch_stock_data(ticker)
        X_train, X_test, y_train, y_test = self.prepare_data(stock_data)

        if model_choice == "Linear Regression":
            model = LinearRegression()
        elif model_choice == "Random Forest":
            model = RandomForestRegressor()
        elif model_choice == "Decision Tree":
            model = DecisionTreeRegressor()
        elif model_choice == "SVR":
            model = SVR()
        elif model_choice == "Gradient Boosting":
            model = GradientBoostingRegressor()

        # Hyperparameter tuning if parameters are provided
        if hyperparams:
            param_grid = self.parse_hyperparameters(hyperparams, model_choice)
            if param_grid:
                model = GridSearchCV(model, param_grid, cv=5)  # 5-fold cross-validation

        model.fit(X_train, y_train)
        predictions = model.predict(X_test)

        mse = mean_squared_error(y_test, predictions)
        r2 = r2_score(y_test, predictions)

        result_text = f"Model: {model_choice}\nMSE: {mse}\nR²: {r2}\n"
        self.result_area.setPlainText(result_text)

    def parse_hyperparameters(self, params_str, model_choice):
        """Parse the hyperparameter input string into a dictionary."""
        param_grid = {}
        try:
            params = [p.split('=') for p in params_str.split(',')]
            for param in params:
                key, value = param[0].strip(), param[1].strip()
                # Handle specific models and their hyperparameters
                if model_choice == "Random Forest":
                    if key in ["n_estimators", "max_depth"]:
                        param_grid[key] = [int(value)]
                elif model_choice == "Gradient Boosting":
                    if key in ["n_estimators", "learning_rate", "max_depth"]:
                        param_grid[key] = [float(value) if '.' in value else int(value)]
                elif model_choice == "SVR":
                    if key in ["C", "epsilon"]:
                        param_grid[key] = [float(value)]
                elif model_choice == "Decision Tree":
                    if key in ["max_depth", "min_samples_split"]:
                        param_grid[key] = [int(value)]
            return param_grid
        except Exception as e:
            print("Error parsing hyperparameters:", e)
            return {}

if __name__ == "__main__":
    app = QApplication(sys.argv)
    ex = StockPredictorApp()
    ex.show()
    sys.exit(app.exec_())
'''
#with hypertuning with   hyper otp
import sys
import sqlite3
import numpy as np
import pandas as pd
from hyperopt import fmin, tpe, hp, STATUS_OK, Trials
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.tree import DecisionTreeRegressor
from sklearn.svm import SVR
from sklearn.metrics import mean_squared_error
from PyQt5.QtWidgets import (QApplication, QWidget, QVBoxLayout, QLabel, 
                             QPushButton, QComboBox, QTextEdit)

class StockPredictorApp(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.setWindowTitle("Stock Predictor")
        layout = QVBoxLayout()

        self.stock_label = QLabel("Select Stock:")
        self.stock_combo = QComboBox()
        self.stock_combo.addItems(["RELIANCE_NS", "HDFCBANK_NS", "ICICIBANK_NS"])  # Add more tickers

        self.model_label = QLabel("Select Model:")
        self.model_combo = QComboBox()
        self.model_combo.addItems(["Linear Regression", "Random Forest", "Decision Tree", "SVR", "Gradient Boosting"])

        self.result_area = QTextEdit()
        self.result_area.setReadOnly(True)

        self.train_button = QPushButton("Train Model")
        self.train_button.clicked.connect(self.train_model)

        layout.addWidget(self.stock_label)
        layout.addWidget(self.stock_combo)
        layout.addWidget(self.model_label)
        layout.addWidget(self.model_combo)
        layout.addWidget(self.train_button)
        layout.addWidget(self.result_area)

        self.setLayout(layout)

    def fetch_stock_data(self, ticker):
        conn = sqlite3.connect('nifty50_data.db')
        query = f"SELECT * FROM {ticker.replace('.', '_')}"
        stock_df = pd.read_sql(query, conn)
        stock_df['Date'] = pd.to_datetime(stock_df['Date'])
        conn.close()
        return stock_df

    def prepare_data(self, df):
        df = df[['Date', 'Open', 'High', 'Low', 'Close', 'Volume']].dropna()
        df['Date'] = pd.to_numeric(df['Date'])
        X = df[['Date', 'Open', 'High', 'Low', 'Volume']]
        y = df['Close']
        return train_test_split(X, y, test_size=0.2, random_state=42)

    def objective(self, params, model_choice, X_train, y_train):
        if model_choice == "Random Forest":
            model = RandomForestRegressor(n_estimators=int(params['n_estimators']), max_depth=int(params['max_depth']))
        elif model_choice == "Gradient Boosting":
            model = GradientBoostingRegressor(n_estimators=int(params['n_estimators']), learning_rate=params['learning_rate'], max_depth=int(params['max_depth']))
        elif model_choice == "SVR":
            model = SVR(C=params['C'], epsilon=params['epsilon'])
        elif model_choice == "Decision Tree":
            model = DecisionTreeRegressor(max_depth=int(params['max_depth']), min_samples_split=int(params['min_samples_split']))
        else:
            model = LinearRegression()  # No hyperparameters for linear regression
        
        model.fit(X_train, y_train)
        preds = model.predict(X_train)
        mse = mean_squared_error(y_train, preds)
        return {'loss': mse, 'status': STATUS_OK}

    def train_model(self):
        ticker = self.stock_combo.currentText()
        model_choice = self.model_combo.currentText()

        stock_data = self.fetch_stock_data(ticker)
        X_train, X_test, y_train, y_test = self.prepare_data(stock_data)

        # Define hyperparameter space based on the chosen model
        if model_choice == "Random Forest":
            space = {
                'n_estimators': hp.choice('n_estimators', [50, 100, 200]),
                'max_depth': hp.choice('max_depth', [5, 10, 20])
            }
        elif model_choice == "Gradient Boosting":
            space = {
                'n_estimators': hp.choice('n_estimators', [50, 100, 200]),
                'learning_rate': hp.uniform('learning_rate', 0.01, 0.2),
                'max_depth': hp.choice('max_depth', [3, 5, 10])
            }
        elif model_choice == "SVR":
            space = {
                'C': hp.loguniform('C', 0, 5),  # Log-uniform distribution
                'epsilon': hp.uniform('epsilon', 0, 1)
            }
        elif model_choice == "Decision Tree":
            space = {
                'max_depth': hp.choice('max_depth', [5, 10, 20]),
                'min_samples_split': hp.choice('min_samples_split', [2, 5, 10])
            }
        else:  # Linear Regression
            self.result_area.setPlainText("Linear Regression does not require hyperparameters.")
            return

        trials = Trials()
        best = fmin(fn=lambda params: self.objective(params, model_choice, X_train, y_train),
                     space=space,
                     algo=tpe.suggest,
                     max_evals=50,  # Adjust as needed
                     trials=trials)

        self.save_optimal_params(ticker, model_choice, best)
        self.display_results(best, model_choice)

    def save_optimal_params(self, ticker, model_choice, best_params):
        # Save optimal parameters to a database or a file
        conn = sqlite3.connect('optimal_params.db')
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS optimal_params (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ticker TEXT,
                model_choice TEXT,
                params TEXT
            )
        ''')
        cursor.execute('''
            INSERT INTO optimal_params (ticker, model_choice, params)
            VALUES (?, ?, ?)
        ''', (ticker, model_choice, str(best_params)))
        conn.commit()
        conn.close()

    def display_results(self, best, model_choice):
        best_text = f"Optimal Hyperparameters for {model_choice}:\n"
        for key, value in best.items():
            best_text += f"{key}: {value}\n"
        self.result_area.setPlainText(best_text)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    ex = StockPredictorApp()
    ex.show()
    sys.exit(app.exec_())
