import yfinance as yf
import sqlite3
from datetime import datetime, timedelta

# Function to create a SQLite database connection
def create_connection(db_file):
    conn = sqlite3.connect(db_file)
    return conn

# Function to create a table for a specific stock
def create_stock_table(conn, stock_symbol):
    create_table_sql = f'''
    CREATE TABLE IF NOT EXISTS "{stock_symbol}" (
        Date TEXT PRIMARY KEY,
        Open REAL,
        High REAL,
        Low REAL,
        Close REAL,
        Volume INTEGER
    );
    '''
    try:
        cursor = conn.cursor()
        cursor.execute(create_table_sql)
    except sqlite3.Error as e:
        print(e)

# Function to insert stock data into the respective table
def insert_stock_data(conn, stock_symbol, stock_data):
    insert_data_sql = f'''
    INSERT OR IGNORE INTO "{stock_symbol}" (Date, Open, High, Low, Close, Volume)
    VALUES (?, ?, ?, ?, ?, ?);
    '''
    try:
        cursor = conn.cursor()
        cursor.executemany(insert_data_sql, stock_data)
        conn.commit()
    except sqlite3.Error as e:
        print(e)

# Function to fetch historical stock data in small chunks (1 month at a time)
def fetch_historical_data(stock_symbols, conn):
    end_date = datetime.now()
    start_date = datetime(2024, 8, 1)
    chunk_size = timedelta(days=7)  # Fetching data 1 month at a time

    for symbol in stock_symbols:
        print(f'Fetching data for {symbol}...')

        current_start = start_date
        while current_start < end_date:
            current_end = min(current_start + chunk_size, end_date)

            stock = yf.Ticker(symbol)
            stock_data = stock.history(start=current_start, end=current_end, interval='1m')  # Fetching data at 5 min intervals

            if stock_data.empty:
                print(f'{symbol}: No data found for {current_start} to {current_end}')
                current_start += chunk_size
                continue

            # Prepare data for insertion (with time)
            stock_data_tuples = list(zip(stock_data.index.strftime('%Y-%m-%d %H:%M:%S'), 
                                         stock_data['Open'], 
                                         stock_data['High'], 
                                         stock_data['Low'], 
                                         stock_data['Close'], 
                                         stock_data['Volume']))

            # Create table for the stock if it doesn't exist
            create_stock_table(conn, symbol)

            # Insert stock data into the table
            insert_stock_data(conn, symbol, stock_data_tuples)
            print(f'Data from {current_start} to {current_end} for {symbol} stored successfully.')

            # Move to the next chunk
            current_start += chunk_size

# Main execution block
if __name__ == '__main__':
    # List of stock symbols for Nifty 50 companies
    stock_symbols = [
       "RELIANCE.NS", "HDFCBANK.NS", "ICICIBANK.NS", "INFY.NS",
    "TCS.NS", "LT.NS", "KOTAKBANK.NS", "SBIN.NS", "BHARTIARTL.NS",
    "ITC.NS", "HINDUNILVR.NS", "ASIANPAINT.NS", "AXISBANK.NS", "BAJFINANCE.NS",
    "HCLTECH.NS", "MARUTI.NS", "ULTRACEMCO.NS", "TITAN.NS", "SUNPHARMA.NS",
    "ADANIENT.NS", "NTPC.NS", "ONGC.NS", "POWERGRID.NS", "WIPRO.NS",
    "INDUSINDBK.NS", "M&M.NS", "NESTLEIND.NS", "JSWSTEEL.NS", "TECHM.NS",
    "TATAMOTORS.NS", "DIVISLAB.NS", "BPCL.NS", "HEROMOTOCO.NS", "DRREDDY.NS",
    "GRASIM.NS", "CIPLA.NS", "APOLLOHOSP.NS", "TATACONSUM.NS",
    "TATASTEEL.NS", "BRITANNIA.NS", "EICHERMOT.NS", "ADANIPORTS.NS", "BAJAJFINSV.NS",
    "COALINDIA.NS", "HDFCLIFE.NS", "SBILIFE.NS", "UPL.NS", "DEEPAKNTR.NS"
    ]

    # SQLite database file
    database = "stock_data.db"

    # Create database connection
    conn = create_connection(database)

    if conn:
        fetch_historical_data(stock_symbols, conn)
        conn.close()
    else:
        print("Error! Cannot create the database connection.")
