# models.py
from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver

class Profile(models.Model):
    """
    Extending the Django User model with a Profile.
    """
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    bio = models.TextField(blank=True, null=True)  # Bio field for user
    location = models.CharField(max_length=100, blank=True, null=True)  # User location
    birth_date = models.DateField(null=True, blank=True)  # Example field for date of birth
    profile_image = models.ImageField(upload_to='profile_images/', blank=True, null=True)  # Profile picture
# Add more fields here if necessary
    class Meta:
        app_label = 'analysis'
    def __str__(self):
        return f"{self.user.username}'s Profile"

# Signal to create/update Profile automatically when a User instance is created/updated
@receiver(post_save, sender=User)
def create_user_profile(sender, instance, created, **kwargs):
    """
    Signal receiver for automatically creating a profile when a user is created.
    """
    if created:
        Profile.objects.create(user=instance)

@receiver(post_save, sender=User)
def save_user_profile(sender, instance, **kwargs):
    """
    Signal receiver to automatically save the profile when a user is saved.
    """
    instance.profile.save()


class Indice(models.Model):
    name = models.CharField(max_length=255)
    ticker = models.CharField(max_length=25, unique=True)
    current_price = models.FloatField(null=True, blank=True)
    open_price = models.FloatField(null=True, blank=True)
    percentage_change= models.FloatField(null=True, blank=True)
    def __str__(self):
        return f"{self.name},"
# models.py
from django.db import models

class Stock(models.Model):
    name = models.CharField(max_length=255)
    ticker = models.CharField(max_length=25, unique=True)
    current_price = models.FloatField(null=True, blank=True)
    open_price = models.FloatField(null=True, blank=True)
    percentage_change= models.FloatField(null=True, blank=True)
    popular = models.BooleanField(default=False)  # New field to mark stock as popular

    def __str__(self):
        return f"{self.name}"

    def calculate_percentage_change(self):
        """Calculate percentage change based on the current and open prices."""
        if self.open_price:
            return round(((self.current_price - self.open_price) / self.open_price) * 100, 2)
        return None

    def save(self, *args, **kwargs):
        """Override the save method to automatically calculate and store percentage change."""
        self.percentage_change = self.calculate_percentage_change()
        super(Stock, self).save(*args, **kwargs)
