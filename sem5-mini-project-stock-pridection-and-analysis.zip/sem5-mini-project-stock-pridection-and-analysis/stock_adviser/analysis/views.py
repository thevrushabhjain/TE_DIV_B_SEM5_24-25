from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.views import View
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
import json
from .models import Stock, Indice  # Assuming you have Stock and Indice models


# Home View (Displays stocks and indices)
class HomeView(View):
    def get(self, request):
        # Fetch all stocks and indices to display on the homepage
        stocks = Stock.objects.all()
        indices = Indice.objects.all()
        Popular_stocks=Stock.objects.filter(popular=True)

        for stock in stocks:
                if stock.open_price:  # Ensure open_price is not zero to avoid division by zero
                    stock.percentage_change = round(((stock.current_price - stock.open_price) / stock.open_price) * 100, 2)
                else:
                    stock.percentage_change = 0

            # Get top 3 gainers and losers
        top_gainers = sorted(stocks, key=lambda x: x.percentage_change, reverse=True)[:3]
        top_losers = sorted(stocks, key=lambda x: x.percentage_change)[:3]


        context = {
            'stocks': stocks,
            'indices': indices,
            'most_bought':Popular_stocks,
            'top_gainers': top_gainers,
            'top_losers': top_losers,
        }
        return render(request, 'base.html', context)


# Stock View (Displays individual stock's details)
from django.shortcuts import get_object_or_404
from django.views import View
from .models import Stock,Profile,create_user_profile  # Import your Stock model
import os
from django.views import View
from django.shortcuts import get_object_or_404, render
import json
class StockView(View):
    def get(self, request, name):
        # Fetch stock details based on the ticker symbol
        stock = get_object_or_404(Stock, name=name)

        # Load prediction data from JSON file
        predictions_file_path = r"C:\Users\Shubham\OneDrive\Desktop\project mini\stock_adviser\data\long_term\predictions.json"
        with open(predictions_file_path, 'r') as file:
            predictions_data = json.load(file)

        # Print the entire predictions data for debugging
        print("Predictions Data Loaded:", predictions_data)

        # Get predictions for the specific stock
        predictions = predictions_data.get(stock.ticker, {})
        print("Predictions for", stock.ticker, ":", predictions)

        if not predictions:
            predictions = {
                "15_days": "Data not available",
                "1_month": "Data not available",
                "6_months": "Data not available",
                "1_year": "Data not available"
            }
        
        context = {
            'stock': stock.name,
            'ticker': stock.ticker,
            'current_price': stock.current_price,
            'open_price': stock.open_price,
            'percentage_change': stock.percentage_change,
            'predictions': predictions,
        }
        return render(request, 'stock_chart.html', context)

# Login View (User login functionality)
class LoginView(View):
    def get(self, request):
        return render(request, 'login.html')

    def post(self, request):
        username = request.POST.get('username')
        password = request.POST.get('password')
        
        if username and password:
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('home')
            else:
                return render(request, 'login.html', {'error': 'Invalid username or password'})
        else:
            return render(request, 'login.html', {'error': 'Please fill in both fields'})


# Logout View (Handles user logout)
def logout_view(request):
    logout(request)
    return redirect('login')
from django.db import IntegrityError
from django.core.exceptions import ValidationError

class RegisterView(View):
    def get(self, request):
        return render(request, 'register.html')

    def post(self, request):
        username = request.POST.get('username')
        password = request.POST.get('password')

        # Ensure both fields are filled
        if not username or not password:
            return render(request, 'register.html', {'error': 'Please fill in both fields'})

        try:
            # Create the user
            user = User.objects.create_user(username=username, password=password)
            user.save()

            return redirect('login')
        
        except IntegrityError:
            # Handle the case when the username is already taken
            return render(request, 'register.html', {'error': 'Username is already taken. Please choose another.'})
        
        except ValidationError as e:
            # Handle validation errors (e.g., password too weak)
            return render(request, 'register.html', {'error': str(e)})
        
        except Exception as e:
            # Handle any other unexpected errors
            return render(request, 'register.html', {'error': f"An unexpected error occurred: {str(e)}"})


# Profile View (User profile, requires login)
@method_decorator(login_required, name='dispatch')
class ProfileView(View):
    def get(self, request):
        return render(request, 'profile.html', {'user': request.user})

import threading
import time
import yfinance as yf
from django.db import transaction
from django.http import JsonResponse
from django.conf import settings
from .models import Stock, Indice

# Global flag to prevent multiple threads from running
updating_data = False

# List of Nifty 50 tickers
nifty_50_tickers = [
    "RELIANCE.NS", "HDFCBANK.NS", "ICICIBANK.NS", "INFY.NS",
    "TCS.NS", "LT.NS", "KOTAKBANK.NS", "SBIN.NS", "BHARTIARTL.NS",
    "ITC.NS", "HINDUNILVR.NS", "ASIANPAINT.NS", "AXISBANK.NS", "BAJFINANCE.NS",
    "HCLTECH.NS", "MARUTI.NS", "ULTRACEMCO.NS", "TITAN.NS", "SUNPHARMA.NS",
    "ADANIENT.NS", "NTPC.NS", "ONGC.NS", "POWERGRID.NS", "WIPRO.NS",
    "INDUSINDBK.NS", "M&M.NS", "NESTLEIND.NS", "JSWSTEEL.NS", "TECHM.NS",
    "TATAMOTORS.NS", "DIVISLAB.NS", "BPCL.NS", "HEROMOTOCO.NS", "DRREDDY.NS",
    "GRASIM.NS", "CIPLA.NS", "APOLLOHOSP.NS", "TATACONSUM.NS",
    "TATASTEEL.NS", "BRITANNIA.NS", "EICHERMOT.NS", "ADANIPORTS.NS", "BAJAJFINSV.NS",
    "COALINDIA.NS", "HDFCLIFE.NS", "SBILIFE.NS", "UPL.NS", "DEEPAKNTR.NS"
]

# List of Indices tickers (adjust to your needs)
indices_list = [
    {"name": "NIFTY", "ticker": "^NSEI"},
    {"name": "SENSEX", "ticker": "^BSESN"},
    {"name": "BANK NIFTY", "ticker": "^NSEBANK"},
]
def update_nifty_50_and_indices_periodically():
    while True:
        try:
            # Update Nifty 50 Stocks
            for ticker in nifty_50_tickers:
                ticker_data = yf.Ticker(ticker)
                data = ticker_data.history(period='1d', interval='1m')

                if not data.empty:
                    current_price = data['Close'].iloc[-1]
                    open_price = data['Open'].iloc[0]

                    # Calculate percentage change
                    if open_price != 0:
                        percentage_change = ((current_price - open_price) / open_price) * 100
                    else:
                        percentage_change = 0.0  # Handle case where open_price is zero

                    # Round to 2 decimal places
                    percentage_change = round(percentage_change, 2)

                    # Update or create Stock data in the database
                    with transaction.atomic():
                        Stock.objects.update_or_create(
                            ticker=ticker,
                            defaults={
                                'name': ticker_data.info.get('shortName', ticker),
                                'current_price': current_price,
                                'open_price': open_price,
                                'percentage_change': percentage_change,  # Save percentage change
                            }
                        )

            # Update Indices
            for index in indices_list:
                ticker_data = yf.Ticker(index['ticker'])
                data = ticker_data.history(period='1d')

                if not data.empty:
                    current_price = data['Close'].iloc[-1]
                    open_price = data['Open'].iloc[0]

                    # Calculate percentage change
                    if open_price != 0:
                        percentage_change = ((current_price - open_price) / open_price) * 100
                    else:
                        percentage_change = 0.0  # Handle case where open_price is zero

                    # Round to 2 decimal places
                    percentage_change = round(percentage_change, 2)

                    # Update or create Indice data in the database
                    with transaction.atomic():
                        Indice.objects.update_or_create(
                            name=index['name'],
                            ticker=index['ticker'],
                            defaults={
                                'current_price': current_price,
                                'open_price': open_price,
                                'percentage_change': percentage_change,  # Save percentage change
                            }
                        )
        except Exception as e:
            print(f"Error during update: {e}")

        time.sleep(60)  # Wait for 60 seconds before the next update


# View to start the updates
def start_data_updates(request):
    global updating_data
    if settings.DEBUG and not updating_data:  # Only run in debug mode (development) and ensure it's started once
        updating_data = True
        threading.Thread(target=update_nifty_50_and_indices_periodically, daemon=True).start()
    return JsonResponse({'status': 'Nifty 50 and indices updating started'})
from django.shortcuts import render

def stock_chart_view(request, ticker):
    list1={'ADANIENT.NS': 'ADANIENT', 'ADANIPORTS.NS': 'ADANIPORTS',
           'APOLLOHOSP.NS': 'APOLLOHOSP', 'ASIANPAINT.NS': 'ASIANPAINT',
           'AXISBANK.NS': 'AXISBANK', 'BAJAJFINSV.NS': 'BAJAJFINSV',
           'BAJFINANCE.NS': 'BAJFINANCE', 'BHARTIARTL.NS': 'BHARTIARTL', 
           'BPCL.NS': 'BPCL', 'BRITANNIA.NS': 'BRITANNIA', 'CIPLA.NS': 'CIPLA',
           'COALINDIA.NS': 'COALINDIA', 'DEEPAKNTR.NS': 'DEEPAKNTR',
           'DIVISLAB.NS': 'DIVISLAB', 'DRREDDY.NS': 'DRREDDY', 
           'EICHERMOT.NS': 'EICHERMOT', 'GRASIM.NS': 'GRASIM', 
           'HCLTECH.NS': 'HCLTECH', 'HDFCBANK.NS': 'HDFCBANK', 
           'HDFCLIFE.NS': 'HDFCLIFE', 'HEROMOTOCO.NS': 'HEROMOTOCO',
           'HINDUNILVR.NS': 'HINDUNILVR', 'ICICIBANK.NS': 'ICICIBANK', 
           'INDUSINDBK.NS': 'INDUSINDBK', 'INFY.NS': 'INFY', 'ITC.NS': 'ITC',
           'JSWSTEEL.NS': 'JSWSTEEL', 'KOTAKBANK.NS': 'KOTAKBANK', 'LT.NS': 'LT',
           'M&M.NS': 'M_M', 'MARUTI.NS': 'MARUTI', 'NESTLEIND.NS': 'NESTLEIND',
           'NTPC.NS': 'NTPC', 'ONGC.NS': 'ONGC', 'POWERGRID.NS': 'POWERGRID', 
           'RELIANCE.NS': 'RELIANCE', 'SBILIFE.NS': 'SBILIFE', 'SBIN.NS': 'SBIN', 
           'SUNPHARMA.NS': 'SUNPHARMA', 'TATACONSUM.NS': 'TATACONSUM',
           'TATAMOTORS.NS': 'TATAMOTORS', 'TATASTEEL.NS': 'TATASTEEL', 
           'TCS.NS': 'TCS', 'TECHM.NS': 'TECHM', 'TITAN.NS': 'TITAN', 
           'ULTRACEMCO.NS': 'ULTRACEMCO', 'UPL.NS': 'UPL', 'WIPRO.NS': 'WIPRO', '^BSEIN':'SENSEX'}


    
        # Load prediction data from JSON file
    predictions_file_path = r"C:\Users\Shubham\OneDrive\Desktop\project mini\stock_adviser\data\long_term\predictions.json"
    with open(predictions_file_path, 'r') as file:
        predictions_data = json.load(file)

        # Get predictions for the specific stock
    predictions = predictions_data.get(ticker, {})
    print("Predictions for", ticker, ":", predictions)

    if not predictions:
        predictions = {
            "15_days": "Data not available",
            "1_month": "Data not available",
            "6_months": "Data not available",
            "1_year": "Data not available"
            }
        
    tradingview_ticker =list1[ticker]

    # Add additional transformation rules here if necessary

    context = {
        'tradingview_ticker': tradingview_ticker,  # This will now be used in the TradingView widget
        'ticker': ticker, # Original ticker for other uses if needed
        'predictions': predictions,
        
    }

    return render(request, 'stock_chart.html', context)

def index_chart(request, name):
    # Fetch index details based on the name
    index = get_object_or_404(Indice, name=name)
    tradingview_ticker=index
    if name=='^BSEIN':
        
        tradingview_ticker='SENSEX'
    context = {
    'tradingview_ticker': tradingview_ticker,  # This will now be used in the TradingView widget        'ticker': ticker  # Original ticker for other uses if needed
    }
    return render(request, 'stock_chart.html', context)
from django.http import JsonResponse
from .models import Stock, Indice # Assuming Stock and Index are models


def fetch_stock_data(request):
    # Fetch all stocks and indices data
    stocks = Stock.objects.all()
    indices = Indice.objects.all()

    # Prepare stock data with calculated percentage change
    stock_data = []
    for stock in stocks:
        try:
            # Calculate percentage change based on open and current price
            percentage_change = ((stock.current_price - stock.open_price) / stock.open_price) * 100
        except ZeroDivisionError:
            percentage_change = 0.0  # In case the open price is zero

        stock_data.append({
            'name': stock.name,
            'current_price': stock.current_price,
            'open_price': stock.open_price,
            'percentage_change': round(percentage_change, 2)  # Round off to 2 decimal places
        })

    # Prepare indices data
    index_data = []
    for index in indices:
        try:
            # Calculate percentage change based on open and current price
            percentage_change = ((index.current_price - index.open_price) / index.open_price) * 100
        except ZeroDivisionError:
            percentage_change = 0.0  # In case the open price is zero
        index_data.append({
            'name': index.name,
            'value': index.current_price,
            'percentage_change': round(percentage_change, 2),  # Round to 2 decimal places
        })

    # Return the data as a JSON response
    return JsonResponse({
        'stocks': stock_data,
        'indices': index_data,
    })
from django.shortcuts import render
from .models import Stock

class SearchView(View):
    def get(self, request):
        query = request.GET.get('q')  # Get the search term from the query parameter
        if query:
            # Filter stocks based on the search term
            stocks = Stock.objects.filter(name__icontains=query)  # Case-insensitive search on stock names
        else:
            stocks = Stock.objects.none()  # Return no results if no query
        
        context = {
            'stocks': stocks,
            'query': query,  # Pass the query back to the template
        }
        return render(request, 'search_results.html', context)

from django.http import JsonResponse
from .models import Stock
def dynamic_search(request):
    query = request.GET.get('q', '')
    stocks = Stock.objects.filter(name__icontains=query)[:10] if query else []
    return JsonResponse({'stocks': [{'name': stock.name} for stock in stocks]})

#stock_adviser\data\data_fetching\nifty_50_analysis.json