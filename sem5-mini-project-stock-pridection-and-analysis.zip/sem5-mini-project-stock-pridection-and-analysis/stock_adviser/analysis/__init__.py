default_app_config = 'analysis.apps.AnalysisConfig'
