# In analysis/apps.py
from django.apps import AppConfig

class AnalysisConfig(AppConfig):
    name = 'analysis'

    def ready(self):
        from analysis.views import update_nifty_50_and_indices_periodically
        import threading
        import os
        if os.environ.get('RUN_MAIN', None) != 'true':  # Ensure this is the primary process
            return  threading.Thread(target=update_nifty_50_and_indices_periodically, daemon=True).start()
