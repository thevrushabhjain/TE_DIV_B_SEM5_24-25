from django.contrib import admin
from .models import Stock, Indice
from django.contrib import admin
from .models import Stock

@admin.action(description="Mark selected stocks as popular")
def make_popular(modeladmin, request, queryset):
    queryset.update(popular=True)

@admin.action(description="Unmark selected stocks as popular")
def make_not_popular(modeladmin, request, queryset):
    queryset.update(popular=False)

class StockAdmin(admin.ModelAdmin):
    list_display = ['name', 'ticker', 'current_price', 'popular']  # Adding 'popular' to display
    actions = [make_popular, make_not_popular]  # Add actions for marking/unmarking popular stocks
    search_fields = ('name', 'ticker')  # Search functionality for name and ticker
    ordering = ('name',)  # Default ordering by name
    list_per_page = 20  # Number of items to display per page

    # Customizing the form layout
    fieldsets = (
        (None, {
            'fields': ('name', 'ticker',  'popular')  # Include 'popular' in the form layout
        }),
    )

# Register the Stock model with the admin site
admin.site.register(Stock, StockAdmin)

@admin.register(Indice)
class IndiceAdmin(admin.ModelAdmin):
    list_display = ('name',  'ticker')
    search_fields = ('name', 'ticker')
    ordering = ('name',)  # Default ordering by name
    list_per_page = 20  # Number of items to display per page

    # Customizing the form layout
    fieldsets = (
        (None, {
            'fields': ('name', 'ticker')
        }),
    )
